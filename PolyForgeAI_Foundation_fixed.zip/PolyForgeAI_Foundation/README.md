# PolyForge AI — Foundation v0.1

A deliberately small foundation for one workflow:

**Text or reference image → human 3D generation → automatic rigging → GLB export**

This is an architectural starter, not a working AI generator yet. It contains:
- A minimal web UI (text prompt + optional image upload)
- A Three.js viewport for previewing a returned GLB
- A FastAPI API with a single generation workflow
- Explicit interfaces for cloud 3D generation and human auto-rigging
- Honest job states; no fake AI results

## Requirements
- Node.js 20+
- Python 3.10+
- A cloud 3D-generation provider and a human auto-rigging service/model must be selected and configured before real generation can work.

## Run

### Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend
In another terminal:
```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0
```

Open the Vite URL (normally http://localhost:5173).

## Environment
Copy `backend/.env.example` to `backend/.env`; the backend loads it at startup.
`ASSET_OUTPUT_DIR` (default `generated`) is the folder whose files are served at `/generated`.
Do not put API keys in frontend code or commit secrets.

## Workflow architecture
1. `POST /api/generate` accepts prompt and optional reference image.
2. `GenerationProvider` creates or retrieves a human mesh.
3. `RiggingProvider` creates a humanoid skeleton and skin weights.
4. `AssetValidator` checks output metadata and file existence.
5. The API returns a GLB URL (`/generated/<file>`) for the frontend viewer and download.

The provider classes currently raise `NotImplementedError`. This is intentional: choose a real provider before implementing vendor-specific requests.

## Non-goals for this foundation
- Animation editor
- Model library/accounts
- Manual mesh editor
- Training a foundation model from scratch
- Pretending the placeholder is an AI-generated character

## OpenCode first task
Read this README and inspect all files. Install dependencies, run backend/frontend, fix actual errors, and report:
- commands executed
- build/test results
- files changed
- remaining blockers

Do not implement a fake generation result. Keep provider API keys server-side.
