import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'

export default function ModelViewer({ modelUrl }: { modelUrl: string | null }) {
  const host = useRef<HTMLDivElement>(null)
  const sceneRef = useRef<THREE.Scene | null>(null)

  useEffect(() => {
    if (!host.current) return
    const scene = new THREE.Scene(); scene.background = new THREE.Color('#111923'); sceneRef.current = scene
    const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 100); camera.position.set(3.8, 2.5, 5)
    const renderer = new THREE.WebGLRenderer({ antialias: true }); renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.outputColorSpace = THREE.SRGBColorSpace
    host.current.appendChild(renderer.domElement)
    scene.add(new THREE.HemisphereLight(0xdceaff,0x29313b,2))
    const light = new THREE.DirectionalLight(0xffffff,2.2); light.position.set(4,6,4); scene.add(light)
    scene.add(new THREE.GridHelper(8,16,0x405064,0x263442))
    const controls = new OrbitControls(camera,renderer.domElement); controls.target.set(0,1,0); controls.enableDamping=true
    const resize=()=>{if(!host.current)return;const w=host.current.clientWidth,h=host.current.clientHeight;camera.aspect=w/Math.max(h,1);camera.updateProjectionMatrix();renderer.setSize(w,h)}
    const observer=new ResizeObserver(resize);observer.observe(host.current);resize()
    let frame=0;const animate=()=>{frame=requestAnimationFrame(animate);controls.update();renderer.render(scene,camera)};animate()
    return ()=>{cancelAnimationFrame(frame);observer.disconnect();controls.dispose();renderer.dispose();host.current?.removeChild(renderer.domElement)}
  }, [])

  useEffect(() => {
    if (!modelUrl || !sceneRef.current) return
    const loader = new GLTFLoader()
    loader.load(modelUrl, gltf => { sceneRef.current?.add(gltf.scene) }, undefined, err => console.error('Could not load generated GLB',err))
  }, [modelUrl])

  return <div className="viewport" ref={host}><div className="empty">Your rigged character will appear here.<small>Orbit · Zoom · Inspect</small></div></div>
}
