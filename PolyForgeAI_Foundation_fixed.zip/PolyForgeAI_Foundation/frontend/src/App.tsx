import { useState } from 'react'
import ModelViewer from './ModelViewer'

type Job = { job_id: string; status: string; message: string; model_url?: string | null; detail?: string }
const API = 'http://localhost:8000'

export default function App() {
  const [prompt, setPrompt] = useState('Low-poly human game character, full-body, neutral T-pose, clear anatomy, simple clothing, clean topology.')
  const [image, setImage] = useState<File | null>(null)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('Ready to create a character.')
  const [modelUrl, setModelUrl] = useState<string | null>(null)

  async function generate() {
    if (prompt.trim().length < 3) { setMessage('Enter a character description first.'); return }
    setBusy(true); setModelUrl(null); setMessage('Submitting request…')
    try {
      const body = new FormData()
      body.append('prompt', prompt)
      if (image) body.append('image', image)
      const response = await fetch(`${API}/api/generate`, { method: 'POST', body })
      const result: Job = await response.json()
      if (!response.ok) throw new Error(result.detail || result.message || `HTTP ${response.status}`)
      setMessage(`${result.status}: ${result.message}`)
      if (result.model_url) setModelUrl(`${API}${result.model_url}`)
    } catch (error) {
      setMessage(`Backend unavailable: ${String(error)}. Start the FastAPI server.`)
    } finally { setBusy(false) }
  }

  return <main className="shell">
    <header><div className="logo">P</div><div><b>POLYFORGE <i>AI</i></b><small>HUMAN 3D GENERATOR</small></div><span className="version">FOUNDATION 0.1</span></header>
    <section className="intro"><span>TEXT / IMAGE → RIGGED 3D</span><h1>One prompt.<br/><em>One game-ready character.</em></h1><p>Generate a low-poly human, automatically rig its skeleton, and export the result for your game engine.</p></section>
    <section className="workspace">
      <aside className="panel">
        <label>CHARACTER DESCRIPTION</label>
        <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} rows={7}/>
        <label>REFERENCE IMAGE <small>OPTIONAL</small></label>
        <input className="file" type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>setImage(e.target.files?.[0] ?? null)}/>
        {image && <p className="filename">{image.name}</p>}
        <div className="specs"><span>STYLE<strong>Low-poly</strong></span><span>TYPE<strong>Human</strong></span><span>POSE<strong>T-pose</strong></span></div>
        <button disabled={busy} onClick={generate}>{busy ? 'PROCESSING…' : '✦  GENERATE 3D + SKELETON'}</button>
        <div className="status">{message}</div>
        <p className="note">The generation and rigging providers are not connected in this foundation build. The API will report this honestly until they are configured.</p>
      </aside>
      <section className="panel preview"><div className="preview-title">3D OUTPUT PREVIEW</div><ModelViewer modelUrl={modelUrl}/></section>
    </section>
    <footer>POLYFORGE AI · LOW-POLY HUMAN ASSETS</footer>
  </main>
}
