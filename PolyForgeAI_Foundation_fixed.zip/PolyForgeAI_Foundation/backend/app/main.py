import os
import uuid
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.schemas import JobResponse, JobStatus
from app.providers.errors import ProviderNotConfiguredError
from app.providers.generation import UnconfiguredGenerationProvider
from app.providers.rigging import UnconfiguredRiggingProvider
from app.services.pipeline import CharacterPipeline

load_dotenv()

app = FastAPI(title="PolyForge AI", version="0.1.0")

OUTPUT_DIR = Path(os.getenv("ASSET_OUTPUT_DIR", "generated")).expanduser().resolve()
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/generated", StaticFiles(directory=OUTPUT_DIR), name="generated")

origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory job store is for local foundation only. Add a persistent queue later.
JOBS: dict[str, dict] = {}
PIPELINE = CharacterPipeline(
    generator=UnconfiguredGenerationProvider(),
    rigger=UnconfiguredRiggingProvider(),
)


@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "PolyForge AI", "version": "0.1.0"}


async def create_job(prompt: str, image_bytes: bytes | None):
    job_id = str(uuid.uuid4())
    options = {"style": "lowpoly", "character_type": "human", "pose": "T-pose", "target_format": "glb"}
    try:
        output_path = await PIPELINE.create_rigged_human(prompt, image_bytes, options)
        JOBS[job_id] = {
            "status": JobStatus.COMPLETED,
            "message": "Rigged character created.",
            "model_url": f"/generated/{output_path.name}",
        }
    except Exception as exc:
        not_configured = isinstance(exc, ProviderNotConfiguredError) or "not configured" in str(exc).lower()
        JOBS[job_id] = {
            "status": JobStatus.NOT_CONFIGURED if not_configured else JobStatus.FAILED,
            "message": str(exc),
            "model_url": None,
        }
    return JobResponse(job_id=job_id, **JOBS[job_id])


@app.post("/api/generate", response_model=JobResponse)
async def generate(prompt: str = Form(...), image: UploadFile | None = File(default=None)):
    if len(prompt.strip()) < 3:
        raise HTTPException(status_code=400, detail="Please provide a character description.")
    image_bytes = None
    if image:
        if not image.content_type or not image.content_type.startswith("image/"):
            raise HTTPException(status_code=400, detail="Reference file must be an image.")
        image_bytes = await image.read()
        if len(image_bytes) > 12 * 1024 * 1024:
            raise HTTPException(status_code=413, detail="Reference image must be 12 MB or smaller.")
    return await create_job(prompt.strip(), image_bytes)


@app.get("/api/jobs/{job_id}", response_model=JobResponse)
async def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    return JobResponse(job_id=job_id, **job)
