from pathlib import Path
from app.providers.generation import GenerationProvider
from app.providers.rigging import RiggingProvider


class CharacterPipeline:
    def __init__(self, generator: GenerationProvider, rigger: RiggingProvider):
        self.generator = generator
        self.rigger = rigger

    async def create_rigged_human(
        self,
        prompt: str,
        reference_image: bytes | None,
        options: dict,
    ) -> Path:
        mesh = await self.generator.generate_human(prompt, reference_image, options)
        rigged_path = await self.rigger.rig_human(mesh.file_path, options)
        if not rigged_path.exists():
            raise RuntimeError("Rigging provider returned a file path that does not exist.")
        if rigged_path.suffix.lower() not in {".glb", ".gltf"}:
            raise RuntimeError("Rigging output must be GLB or glTF for the first release.")
        return rigged_path
