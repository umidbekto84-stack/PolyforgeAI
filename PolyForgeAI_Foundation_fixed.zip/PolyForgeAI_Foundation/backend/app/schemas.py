from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field


class JobStatus(str, Enum):
    RECEIVED = "received"
    GENERATING_MESH = "generating_mesh"
    RIGGING = "rigging"
    VALIDATING = "validating"
    COMPLETED = "completed"
    FAILED = "failed"
    NOT_CONFIGURED = "not_configured"


class GenerationOptions(BaseModel):
    style: str = "lowpoly"
    character_type: str = "human"
    pose: str = "T-pose"
    target_format: str = "glb"


class JobResponse(BaseModel):
    job_id: str
    status: JobStatus
    message: str
    model_url: Optional[str] = None


class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=2000)
    options: GenerationOptions = GenerationOptions()
