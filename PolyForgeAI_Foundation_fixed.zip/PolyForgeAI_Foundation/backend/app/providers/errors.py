class ProviderNotConfiguredError(RuntimeError):
    """Raised when a real generation or rigging provider has not been selected."""
