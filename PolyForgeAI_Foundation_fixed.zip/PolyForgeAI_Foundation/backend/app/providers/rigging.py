from abc import ABC, abstractmethod
from pathlib import Path

from app.providers.errors import ProviderNotConfiguredError


class RiggingProvider(ABC):
    """Implement a human auto-rigging adapter behind this interface."""

    @abstractmethod
    async def rig_human(self, mesh_path: Path, options: dict) -> Path:
        """Return a path to a rigged asset with a humanoid skeleton and skin weights."""
        raise NotImplementedError


class UnconfiguredRiggingProvider(RiggingProvider):
    async def rig_human(self, mesh_path, options):
        raise ProviderNotConfiguredError(
            "No human auto-rigging provider is configured. Select and implement a rigging pipeline."
        )
