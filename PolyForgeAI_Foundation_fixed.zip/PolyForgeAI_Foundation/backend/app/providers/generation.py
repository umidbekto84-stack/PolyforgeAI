from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path

from app.providers.errors import ProviderNotConfiguredError


@dataclass
class MeshAsset:
    file_path: Path
    format: str = "glb"


class GenerationProvider(ABC):
    """Implement one vendor adapter behind this interface."""

    @abstractmethod
    async def generate_human(
        self,
        prompt: str,
        reference_image: bytes | None,
        options: dict,
    ) -> MeshAsset:
        """Return a path to a generated, unrigged human mesh."""
        raise NotImplementedError


class UnconfiguredGenerationProvider(GenerationProvider):
    async def generate_human(self, prompt, reference_image, options):
        raise ProviderNotConfiguredError(
            "No text/image-to-3D provider is configured. Select a provider and implement its adapter."
        )
